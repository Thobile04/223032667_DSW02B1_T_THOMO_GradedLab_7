import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

/**
 * QUESTION 1 - Requirement 7: Reusable NoticeCard component 
 * Receives a unique notice object through props and renders structured text fields.
 */
export default function NoticeCard({ notice }) {
  return (
    <View style={styles.card}>
      {/* Interpreting JSONPlaceholder structure into clean campus notice tokens */}
      <Text style={styles.noticeId}>Notice ID: {notice.id}</Text>
      <Text style={styles.title}>{notice.title}</Text>
      <Text style={styles.body}>{notice.body}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 8,
    marginBottom: 12,
    borderLeftWidth: 5,
    borderLeftColor: '#E87722', // UJ Signature Orange
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  noticeId: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#666',
    marginBottom: 4,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#002F6C', // UJ Signature Navy Blue
    marginBottom: 6,
  },
  body: {
    fontSize: 14,
    color: '#333',
    lineHeight: 20,
  },
});
