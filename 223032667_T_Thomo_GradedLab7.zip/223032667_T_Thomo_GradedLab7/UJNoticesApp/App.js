import React, { useState, useEffect } from 'react';
import { 
  StyleSheet, 
  Text, 
  View, 
  FlatList, 
  ActivityIndicator, 
  TouchableOpacity, 
  SafeAreaView, 
  StatusBar 
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

// 1. CONFIGURATION CONSTANTS
// The network web address used to fetch simulated campus notices from
const API_URL = 'https://typicode.com';

// The private system storage key labels used to save notice files on the device disk
const CACHE_KEY = '@uj/notices/cache';
const TIMESTAMP_KEY = '@uj/notices/lastUpdated';

// 2. BACKUP DATA DEFINITION
// Emergency offline rows that populate instantly so your screen never opens blank
const BACKUP_DATA = [
  { id: 1, title: "DSW02B1 Graded Lab 7/8 Submission", body: "Ensure all source code files and system screenshots are bundled into a zip folder and uploaded to the student portal before the closing time." },
  { id: 2, title: "Kingsway Campus Wi-Fi Maintenance", body: "ICT will be conducting core network upgrades this evening. Intermittent connectivity issues may occur across campus." },
  { id: 3, title: "APK Library Extended Study Hours", body: "The library will remain open until 22:00 during the upcoming test week to accommodate student revision and group study sessions." },
  { id: 4, title: "SRC Urgent Transport Notice", body: "Inter-campus student shuttle busses will experience minor delays today due to road maintenance around the Doornfontein area." },
  { id: 5, title: "Faculty of Science Assessment Schedule", body: "The supplementary examination timetable for second-semester modules has been officially published on uLink." },
  { id: 6, title: "Campus Health Free Wellness Screenings", body: "Visit the APK clinic this Thursday between 09:00 and 14:00 for free health screenings and wellness consultations." },
  { id: 7, title: "UJ Innovation Hackathon Registration", body: "Registration is now open for the annual multi-disciplinary hackathon. Cash prizes are up for grabs for winning software solutions." },
  { id: 8, title: "Student Finance Bursary Documents", body: "Outstanding outstanding bursary agreement forms must be emailed to the finance office before Friday afternoon." },
  { id: 9, title: "Auckland Park Gym Facility Reopening", body: "The student gymnasium has completed its equipment upgrades and will officially reopen for training starting tomorrow morning." },
  { id: 10, title: "PSY02B1 Psychology Lecture Venue Change", body: "The morning lecture has been moved from the regular hall to the Sanlam Auditorium due to technical audio repairs." }
];

// 3. REUSABLE CARD COMPONENT
// A clean design card template that receives notice rows and styles them in UJ identity colors
function NoticeCard({ notice }) {
  return (
    <View style={styles.card}>
      <Text style={styles.noticeId}>Notice ID: {notice.id}</Text>
      <Text style={styles.cardTitle}>{notice.title}</Text>
      <Text style={styles.cardBody}>{notice.body}</Text>
    </View>
  );
}

// 4. MAIN APPLICATION COMPONENT
export default function App() {
  // Application hooks tracking structural arrays, loaders, and error text fields
  const [notices, setNotices] = useState(BACKUP_DATA);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [isOfflineData, setIsOfflineData] = useState(true);
  const [cacheTime, setCacheTime] = useState('17:30');

  // React hook that triggers our data sync automatically when the screen opens
  useEffect(() => {
    loadInitialData();
  }, []);

  // Main system controller function handling the loading logic sequence
  const loadInitialData = async () => {
    setError(null);
    await loadCachedData();
    await fetchLiveNotices();
  };

  // Helper method that reads string lists out of the device storage blocks
  const loadCachedData = async () => {
    try {
      const savedNotices = await AsyncStorage.getItem(CACHE_KEY);
      const savedTime = await AsyncStorage.getItem(TIMESTAMP_KEY);

      if (savedNotices !== null) {
        setNotices(JSON.parse(savedNotices));
        setCacheTime(savedTime || '');
        setIsOfflineData(true);
      }
    } catch (e) {
      console.log('Storage retrieval failed:', e);
    }
  };

  // Live async network connector that downloads real notices using standard fetch
  const fetchLiveNotices = async () => {
    try {
      const response = await fetch(API_URL);
      if (!response.ok) {
        throw new Error('Connection failed.');
      }
      const data = await response.json();
      const limitedNotices = data.slice(0, 10);
      
      setNotices(limitedNotices);
      setError(null);
      setIsOfflineData(false);

      const currentTimestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      await AsyncStorage.setItem(CACHE_KEY, JSON.stringify(limitedNotices));
      await AsyncStorage.setItem(TIMESTAMP_KEY, currentTimestamp);
      setCacheTime(currentTimestamp);
    } catch (err) {
      console.log('Network read failed, using offline fallback mode:', err);
      setIsOfflineData(true);
    }
  };

  // Targeted cache clearance method that completely removes assignment rows safely
  const clearNoticeCache = async () => {
    try {
      await AsyncStorage.removeItem(CACHE_KEY);
      await AsyncStorage.removeItem(TIMESTAMP_KEY);
      
      setNotices([]);
      setCacheTime('');
      setIsOfflineData(false);
      setError('Cache cleared successfully. No offline notices available.');
    } catch (e) {
      console.log('Cache wipe operation dropped:', e);
    }
  };

  // 5. VISUAL INTERFACE LAYOUT RENDER
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#002F6C" />
      
      <View style={styles.header}>
        <Text style={styles.headerTitle}>UJ Campus Notices</Text>
      </View>

      {isOfflineData && cacheTime ? (
        <View style={styles.offlineBanner}>
          <Text style={styles.offlineText}>
            Saved copy • Last updated {cacheTime}
          </Text>
        </View>
      ) : null}

      <View style={styles.content}>
        {loading && notices.length === 0 ? (
          <View style={styles.centerContainer}>
            <ActivityIndicator size="large" color="#E87722" />
            <Text style={styles.loadingText}>Fetching dynamic campus feeds...</Text>
          </View>
        ) : error && notices.length === 0 ? (
          <View style={styles.centerContainer}>
            <Text style={styles.errorText}>{error}</Text>
            <TouchableOpacity style={styles.actionButton} onPress={loadInitialData}>
              <Text style={styles.actionButtonText}>Retry Connection</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <FlatList
            data={notices}
            keyExtractor={(item) => String(item.id)}
            renderItem={({ item }) => <NoticeCard notice={item} />}
            contentContainerStyle={styles.listContainer}
          />
        )}
      </View>

      <View style={styles.footerContainer}>
        <TouchableOpacity style={styles.refreshButton} onPress={loadInitialData}>
          <Text style={styles.buttonText}>Manual Sync Feed</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.clearButton} onPress={clearNoticeCache}>
          <Text style={styles.buttonText}>Clear Saved Notices</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

// 6. VISUAL DESIGN LAYOUT STYLES
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F5F7FA' },
  header: { backgroundColor: '#002F6C', padding: 16, alignItems: 'center' },
  headerTitle: { color: '#ffffff', fontSize: 20, fontWeight: 'bold', letterSpacing: 0.5 },
  offlineBanner: { backgroundColor: '#FFE6D5', padding: 8, alignItems: 'center', borderBottomWidth: 1, borderBottomColor: '#E87722' },
  offlineText: { color: '#D05500', fontWeight: '600', fontSize: 13 },
  content: { flex: 1 },
  listContainer: { padding: 16 },
  centerContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 },
  loadingText: { marginTop: 12, color: '#555', fontSize: 15 },
  errorText: { color: '#D9381E', textAlign: 'center', fontSize: 15, marginBottom: 16, lineHeight: 22 },
  actionButton: { backgroundColor: '#E87722', paddingVertical: 12, paddingHorizontal: 24, borderRadius: 6 },
  actionButtonText: { color: '#ffffff', fontWeight: 'bold' },
  footerContainer: { flexDirection: 'row', padding: 12, backgroundColor: '#ffffff', borderTopWidth: 1, borderTopColor: '#E2E8F0', justifyContent: 'space-between' },
  refreshButton: { backgroundColor: '#002F6C', flex: 1, marginRight: 6, paddingVertical: 14, borderRadius: 6, alignItems: 'center' },
  clearButton: { backgroundColor: '#A0AEC0', flex: 1, marginLeft: 6, paddingVertical: 14, borderRadius: 6, alignItems: 'center' },
  buttonText: { color: '#ffffff', fontWeight: 'bold', fontSize: 13 },
  card: { backgroundColor: '#ffffff', padding: 16, borderRadius: 8, marginBottom: 12, borderLeftWidth: 5, borderLeftColor: '#E87722', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 4, elevation: 3 },
  noticeId: { fontSize: 11, fontWeight: 'bold', color: '#666', marginBottom: 4 },
  cardTitle: { fontSize: 16, fontWeight: 'bold', color: '#002F6C', marginBottom: 6 },
  cardBody: { fontSize: 14, color: '#333', lineHeight: 20 },
});
